package com.joabsonlg.tictactoewebsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TictactoewebsocketApplicationTests {

    @Test
    void contextLoads() {
    }

}
